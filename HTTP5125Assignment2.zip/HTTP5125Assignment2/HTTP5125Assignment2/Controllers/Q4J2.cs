﻿using Microsoft.AspNetCore.Mvc;

namespace HTTP5125Assignment2.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class Q4J2 : Controller
    {
        /// <summary>
        /// This method handles the silent auction logic, where it determines the highest bid from the given list of bids.
        /// </summary>
        /// <param name="N">The number of bids to process.</param>
        /// <param name="bids">An array of bid objects containing a person's name and the bid amount.</param>
        /// <returns>
        /// A string containing the name of the person with the highest bid.
        /// </returns>
        /// <example>
        /// Example usage:
        /// POST /api/Q4J2/SilentAuction?N=3
        /// Body:
        /// [
        ///   { "Name": "Ahmed", "Bid": 300 },
        ///   { "Name": "Suzanne", "Bid": 500 },
        ///   { "Name": "Ivona", "Bid": 450 }
        /// ]
        /// Response:
        /// "Suzanne"
        /// </example>

        [HttpPost("SilentAuction")]
        public IActionResult SilentAuction(int N, BidClass[] bids)
        {
            string winnerName = "";
            int highestBid = 0;

            if (N == null && bids != null && bids.Length > 0)
                N = bids.Count();

            for (int i = 0; i < N; i++)
            {
                string name = bids[i].Name;

                //update the winner if the current bid is higher than the highest bid --Commented by Kunal
                if (bids[i].Bid > highestBid)
                {
                    highestBid = bids[i].Bid;
                    winnerName = name;
                }
            }

            return Ok(winnerName);
        }
    }

    public class BidClass
    {
        public string Name { get; set; }
        public int Bid { get; set; }
    }
}
