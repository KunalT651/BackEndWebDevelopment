﻿using Microsoft.AspNetCore.Mvc;

namespace HTTP5125Assignment2.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class J1Controller : Controller
    {
        /// <summary>
        /// This method calculates the performance score for the Delivedroid robot based on its number of collisions and deliveries.
        /// </summary>
        /// <param name="collisions">The number of collisions made by the robot during the task.</param>
        /// <param name="deliveries">The number of successful deliveries made by the robot.</param>
        /// <returns>
        /// Returns the calculated score as an integer. The score is based on the following formula:
        /// (deliveries * 50) - (collisions * 10) and if deliveries exceed collisions, an additional 500 points are added.
        /// </returns>
        /// <example>
        /// Example input:
        /// collisions = 2, deliveries = 5
        /// 
        /// Example output:
        /// 730
        /// </example>
        [HttpPost("Delivedroid")]
        public IActionResult DelivedroidPerformance(int collisions, int deliveries)
        {
            int score = (deliveries * 50) - (collisions * 10);

            if (deliveries > collisions)
            {
                score += 500;
            }

            return Ok(score);
        }
    }
}
