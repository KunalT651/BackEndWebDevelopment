﻿using Microsoft.AspNetCore.Mvc;

namespace HTTP5125Assignment2.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class Q5J3Controller : Controller
    {
        /// <summary>
        /// This method decodes the secret instructions and returns a list of directions with the number of steps to take.
        /// The directions are based on the sum of the first two digits of the instruction code.
        /// </summary>
        /// <param name="instructionsList">A list of instructions represented as strings, where each string is a 5-digit number.</param>
        /// <returns>
        /// A list of strings representing decoded direction followed by the number of steps to take.
        /// </returns>
        /// <example>
        /// Example usage:
        /// POST /api/Q5J3/SecretInstructions
        /// Body:
        /// [
        ///   "57234",
        ///   "00907",
        ///   "34100",
        ///   "99999"
        /// ]
        /// Response:
        /// [
        ///   "right 234",
        ///   "right 907",
        ///   "left 100"
        /// ]
        /// </example>

        [HttpPost("SecretInstructions")]
        public IActionResult SecretInstructions(List<string> instructionsList)
        {
            List<string> outputInstructionsList = new List<string>();
            string previousDirection = "";

            foreach (string instruction in instructionsList)
            {
                //Conditions according to input specifications --Commented by Kunal
                if (!int.TryParse(instruction, out int result) || instruction == "99999" || instruction.Length != 5 || instructionsList[0].StartsWith("00")
                    || instructionsList.Count < 2 || instructionsList[instructionsList.Count - 1] != "99999")
                {
                    break;
                }

                int directionSum = int.Parse(instruction[0].ToString()) + int.Parse(instruction[1].ToString()); //Sum of first 2 digits --Commented by Kunal
                string direction;

                if (directionSum == 0)
                {
                    direction = previousDirection;  // Same as the previous direction
                }
                else if (directionSum % 2 == 0)
                {
                    direction = "right";
                }
                else
                {
                    direction = "left";
                }

                // Get the number of steps
                int steps = int.Parse(instruction.Substring(2, 3));

                if (directionSum != 0)
                {
                    previousDirection = direction;
                }

                // Add the decoded instruction according to output specification --Commented by Kunal
                if(steps >= 100 && (direction == "right" || direction == "left"))
                    outputInstructionsList.Add(direction + " " + steps);
            }

            return Ok(outputInstructionsList);
        }
    }
}
